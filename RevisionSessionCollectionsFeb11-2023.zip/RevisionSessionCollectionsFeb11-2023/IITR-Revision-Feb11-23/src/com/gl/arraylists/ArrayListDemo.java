package com.gl.arraylists;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.gl.entity.Employee;
import com.gl.entity.IdSorter;
import com.gl.entity.SalarySorter;

public class ArrayListDemo {

	ArrayList <Employee> employees = new ArrayList<Employee>();
	public void populateArrayList() //Userdefined method
	{
		Employee e1 = new Employee("E001","Rakesh","Bangalore","929929929",10000);
		employees.add(e1);
		employees.add(new Employee("E002","Saketh","Mangalore","964529929",12000));
		employees.add(new Employee("E003","Mahesh","Ahmedabad","964564529",13000));
		employees.add(new Employee("E004","Keerthana","Faridabad","9726329929",12000));
		employees.add(new Employee("E005","Emanuel","Ernakulam","9645276839",10500));
		employees.add(new Employee("E006","Yaseen","Coimbatore","965349929",17000));
		
		employees.add(2, new Employee("E007","Suman","Chandigarh","968764529",11000));
		
	}
	public void displayArrayList()// Userdefined
	{
		Iterator <Employee> empIter = employees.iterator();
	
		
		System.out.println("Employees in the List are ....");
		while(empIter.hasNext())
		{
			Employee e = empIter.next();
			System.out.println(e);
		}
		System.out.println("-----------------get Employee of index 2-------------");
		System.out.println(employees.get(2));
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListDemo alDemo = new ArrayListDemo();
	/*	alDemo.populateArrayList();
		alDemo.displayArrayList(); */
		
		ArrayList <Employee> employees1 = new ArrayList<Employee>();
		Employee e1 = new Employee("E004","Rakesh","Bangalore","929929929",10000);
		employees1.add(e1);
		employees1.add(new Employee("E002","Saketh","Mangalore","964529929",12000));
		employees1.add(new Employee("E003","Mahesh","Ahmedabad","964564529",13000));
		employees1.add(new Employee("E004","Keerthana","Faridabad","9726329929",12000));
		employees1.add(new Employee("E001","Emanuel","Ernakulam","9645276839",10500));
		
		System.out.println("ID Sorted for Employees");
		Collections.sort(employees1, new IdSorter());
		Iterator idIter = employees1.iterator();
		while(idIter.hasNext())
		{
			System.out.println(idIter.next());
		}
		System.out.println("-------Salary Sorted --------");
		System.out.println("Salary Sorted for Employees");
		Collections.sort(employees1, new SalarySorter());
		Iterator salIter = employees1.iterator();
		while(salIter.hasNext())
		{
			System.out.println(salIter.next());
		}
	}

}
