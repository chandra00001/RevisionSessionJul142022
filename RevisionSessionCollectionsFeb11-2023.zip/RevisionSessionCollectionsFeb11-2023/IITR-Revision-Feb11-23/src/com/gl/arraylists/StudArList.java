package com.gl.arraylists;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.gl.entity.Student;

public class StudArList {

	
	
	/*public void populateARList()
	{
		
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Student> students = new ArrayList<Student>();
		
		students.add(new Student("S003","Bhaskar","Ahmedabad",87));
		students.add(new Student("S004","Chandu","Faridabad",80));
		students.add(new Student("S001","Emanuel","Calcutta",97));
		students.add(new Student("S002","David","Bangalore",83));
		
		Collections.sort(students);
	/*	System.out.println("The Students Sorted based on Student Id ");
		Iterator <Student> studIter = students.iterator();
		while(studIter.hasNext())
		{
			Student student = studIter.next();
			System.out.println(student);
		} */
		System.out.println("The Students Sorted based on Student City ");
		Iterator <Student> studIter = students.iterator();
		while(studIter.hasNext())
		{
			Student student = studIter.next();
			System.out.println(student);
		}
		
		
		
		
	}

}
