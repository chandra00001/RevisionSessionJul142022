package com.gl.stacksqueues;

import java.util.Stack;

import com.gl.entity.Employee;

public class StackSample {

		Stack <Employee> stack = new Stack<Employee>();
		
		/*
		 * Employee e1 = new Employee("E001","Rakesh","Bangalore","929929929",10000);
		employeesLL.add(e1);
		employeesLL.add(new Employee("E002","Saketh","Mangalore","964529929",12000));
		employeesLL.add(new Employee("E003","Mahesh","Ahmedabad","964564529",13000));
		employeesLL.add(new Employee("E004","Keerthana","Faridabad","9726329929",12000));
		employeesLL.add(new Employee("E005","Emanuel","Ernakulam","9645276839",10500));
		employeesLL.add(new Employee("E006","Yaseen","Coimbatore","965349929",17000));
		employeesLL.add(4, new Employee("E007","Srikanth","Chennai","964574629",13000));
		 */
		public void pushObject()
		{
			stack.push(new Employee("E007","Srikanth","Chennai","964574629",13000));
			stack.push(new Employee("E006","Yaseen","Coimbatore","965349929",17000));
			stack.push(new Employee("E005","Emanuel","Ernakulam","9645276839",10500));
			stack.push(new Employee("E004","Keerthana","Faridabad","9726329929",12000));
			stack.push(new Employee("E003","Mahesh","Ahmedabad","964564529",13000));
			stack.push(new Employee("E002","Saketh","Mangalore","964529929",12000));
			stack.push(new Employee("E001","Rakesh","Bangalore","929929929",10000));
		}
		public void popObjects()
		{
			while(stack.isEmpty() != true)
			{
				Employee e = stack.pop();
				System.out.println("The Popped Object is "+e);
			}/**/
			/*System.out.println(stack.peek());
			System.out.println(stack.peek());*/
		}
	
	
	//Push POP
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackSample ss = new StackSample();
		ss.pushObject();
		ss.popObjects();
		System.out.println("-------");
		ss.popObjects();

	}

}
