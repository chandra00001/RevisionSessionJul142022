package com.gl.stacksqueues;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {

	Queue <Integer> myQueue = new PriorityQueue<Integer>();
	
	public void populateQueue()
	{
		myQueue.add(2000);
		myQueue.add(1500);
		myQueue.add(4500);
		myQueue.add(3000);
		myQueue.add(7000);
		myQueue.add(2500);
		//peek poll(return null) or remove (will throw exception when it is empty)
	}
	public void TraverseQueue()
	{
		while(myQueue.isEmpty() != true)
		{
			System.out.println("The Element in Queue is "+myQueue.poll());
		}
	}
	public void fetchQueueElements()
	{
		Iterator <Integer> intIter = myQueue.iterator();
		while(intIter.hasNext())
		{
			System.out.println("Element in Queue is "+intIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueSample qs = new QueueSample();
		qs.populateQueue();
	//	qs.TraverseQueue();
		System.out.println("-------------");
		//qs.TraverseQueue();
		qs.fetchQueueElements();
		qs.TraverseQueue();
		qs.TraverseQueue();

	}

}
