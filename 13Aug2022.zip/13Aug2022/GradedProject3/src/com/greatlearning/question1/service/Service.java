package com.greatlearning.question1.service;

import java.util.PriorityQueue;

public class Service {

	public void printConstructionTable(int floor[],int noOfFloor) {
		
	System.out.println("The order of construction is as follows");
	PriorityQueue <Integer> queue = new PriorityQueue<>(java.util.Collections.reverseOrder());
	//	PriorityQueue<Integer> queue = new PriorityQueue<>();
	int[] tempArray = new int[noOfFloor];

	int max = noOfFloor;

	System.out.println();
	for (int i = 0; i < noOfFloor; i++) {

		System.out.println("Day: "+(i+1));
		
		
		tempArray[i] = floor[i];

		queue.add(tempArray[i]);

		//one by one elements are added
		//First time 1 element added
		//if it is max displays
		//else nothing would be displayed
		
		//If its max then only polling would happen
		//else accumulates
		while (!queue.isEmpty() && queue.peek() == max) {

			System.out.print(queue.poll() + " ");

			max--;
		}
	System.out.println();
	}
 }
}
