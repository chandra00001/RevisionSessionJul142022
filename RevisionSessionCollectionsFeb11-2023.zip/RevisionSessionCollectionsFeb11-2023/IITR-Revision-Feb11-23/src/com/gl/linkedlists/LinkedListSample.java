package com.gl.linkedlists;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.gl.entity.Employee;

public class LinkedListSample {

	List <Employee> employeesLL = new LinkedList<Employee>();
	public void populateLinkedList()
	{
		Employee e1 = new Employee("E001","Rakesh","Bangalore","929929929",10000);
		employeesLL.add(e1);
		employeesLL.add(new Employee("E002","Saketh","Mangalore","964529929",12000));
		employeesLL.add(new Employee("E003","Mahesh","Ahmedabad","964564529",13000));
		employeesLL.add(new Employee("E004","Keerthana","Faridabad","9726329929",12000));
		employeesLL.add(new Employee("E005","Emanuel","Ernakulam","9645276839",10500));
		employeesLL.add(new Employee("E006","Yaseen","Coimbatore","965349929",17000));
		employeesLL.add(4, new Employee("E007","Srikanth","Chennai","964574629",13000));
	}
	//Comparator/Comparable
	public void displayLinkedListInInsertionOrder()
	{
		Iterator <Employee> empLLIter = employeesLL.iterator();
		
		
		System.out.println("Employees in the LinkedList collection are ");
		while(empLLIter.hasNext())
		{
			Employee e = empLLIter.next();
			System.out.println(e);
			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSample llSample = new LinkedListSample();
		llSample.populateLinkedList();
		llSample.displayLinkedListInInsertionOrder();

	}

}
