package com.gl.entity;

public class Student implements Comparable <Student> {

	String studId;
	String studName;
	
	

	String studCity;
	int score;
	
	public Student() {
		super();
	}



	public Student(String studId, String studCity, int score) {
		super();
		this.studId = studId;
		this.studCity = studCity;
		this.score = score;
	}
	public Student(String studId, String studName, String studCity, int score) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studCity = studCity;
		this.score = score;
	}

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getStudCity() {
		return studCity;
	}

	public void setStudCity(String studCity) {
		this.studCity = studCity;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}



	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studCity=" + studCity + ", score=" + score
				+ "]";
	}

// st1  st2 st3 
//S001 S001
	//Sort based on StudId - String - compareTo
	/*@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if(this.studId.compareTo(o.studId) > 0 )
		{
			return 1;
		}
		else if (this.studId.compareTo(o.studId) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}

	}*/
	
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if(this.studCity.compareTo(o.studCity) > 0 )
		{
			return 1;
		}
		else if (this.studCity.compareTo(o.studCity) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}

	}
	
	
}

