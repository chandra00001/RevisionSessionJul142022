package com.greatlearning.queuecheck;

import java.util.PriorityQueue;

public class ReverseQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PriorityQueue<Integer> queue = new PriorityQueue<>(java.util.Collections.reverseOrder());
		queue.add(50);
		queue.add(40);
		queue.add(10);
		queue.add(30);
		queue.add(20);
		while (!queue.isEmpty()) 
		{

			System.out.print(queue.poll() + " ");

		}
	}

}
