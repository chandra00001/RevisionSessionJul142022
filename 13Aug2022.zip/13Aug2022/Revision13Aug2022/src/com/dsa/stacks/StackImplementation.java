package com.dsa.stacks;

public class StackImplementation {

	static final int sizeOfStack = 1000;
	int currentPointer;
	int stackArray[] = new int[sizeOfStack];
	
	public StackImplementation()
	{
		currentPointer = -1;
	}
	public boolean push(int x)
	{
		if(currentPointer >= sizeOfStack-1)
		{
			System.out.println("Stack Over Flow");
			return false;
		}
		else
		{
			stackArray[++currentPointer] = x;
			System.out.println(x+" Pushed into Stack");
			return true;
		}
	}
	public int pop()
	{
		if(currentPointer < 0)
		{
			System.out.println("Stack Underflow");
			return 0;
		}
		else
		{
			int x = stackArray[currentPointer--];
			return x;
		}
	}
	public void printStack()
	{
		for(int i=currentPointer;i>-1;i--)
		{
			System.out.println(" "+stackArray[i]);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StackImplementation stack = new StackImplementation();
		stack.push(45);
		stack.push(55);
		stack.push(65);
		stack.push(75);
		stack.push(85);
		System.out.println("Popped Element "+stack.pop());
		System.out.println("Elements in Stack ");
		stack.printStack();
		

	}

}
